import tkinter as tk

class TodoListApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List")

        self.tasks = []

        self.task_entry = tk.Entry(root, width=50)
        self.task_entry.pack(pady=5)

        self.add_button = tk.Button(root, text="Add Task", command=self.add_task)
        self.add_button.pack()

        self.task_listbox = tk.Listbox(root, width=70)
        self.task_listbox.pack(pady=5)

        self.remove_button = tk.Button(root, text="Remove Task", command=self.remove_task)
        self.remove_button.pack()

        self.mark_button = tk.Button(root, text="Mark as Completed", command=self.mark_as_completed)
        self.mark_button.pack()

        self.priority_var = tk.StringVar()
        self.priority_var.set("All")
        self.priority_menu = tk.OptionMenu(root, self.priority_var, "All", "Low", "Medium", "High", command=self.filter_tasks_by_priority)
        self.priority_menu.pack()

        self.load_button = tk.Button(root, text="Load Tasks", command=self.load_tasks)
        self.load_button.pack()

        self.save_button = tk.Button(root, text="Save Tasks", command=self.save_tasks)
        self.save_button.pack()

    def add_task(self):
        task_description = self.task_entry.get()
        if task_description:
            task = {'description': task_description, 'completed': False, 'priority': 'Medium', 'due_date': ''}
            self.tasks.append(task)
            self.update_task_listbox()
            self.task_entry.delete(0, tk.END)

    def remove_task(self):
        selected_index = self.task_listbox.curselection()
        if selected_index:
            index = selected_index[0]
            del self.tasks[index]
            self.update_task_listbox()

    def mark_as_completed(self):
        selected_index = self.task_listbox.curselection()
        if selected_index:
            index = selected_index[0]
            self.tasks[index]['completed'] = True
            self.update_task_listbox()

    def filter_tasks_by_priority(self, priority):
        if priority == "All":
            self.update_task_listbox()
        else:
            filtered_tasks = [task for task in self.tasks if task['priority'] == priority]
            self.update_task_listbox(filtered_tasks)

    def update_task_listbox(self, tasks=None):
        self.task_listbox.delete(0, tk.END)
        tasks = tasks or self.tasks
        for task in tasks:
            task_description = task['description']
            if task['completed']:
                task_description += " (Completed)"
            self.task_listbox.insert(tk.END, task_description)

    def load_tasks(self):
        try:
            with open('tasks.json', 'r') as file:
                self.tasks = json.load(file)
            self.update_task_listbox()
        except FileNotFoundError:
            messagebox.showinfo("File Not Found", "No tasks file found.")

    def save_tasks(self):
        with open('tasks.json', 'w') as file:
            json.dump(self.tasks, file)
        messagebox.showinfo("Save Complete", "Tasks saved successfully.")

def main():
    root = tk.Tk()
    app = TodoListApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
